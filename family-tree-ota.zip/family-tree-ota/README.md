# Family Tree (native Android shell + index.html + OTA)

- UI is `app/src/main/assets/index.html` (bundled in the APK, runs in a WebView; works offline)
- OTA: on launch the app downloads the latest `index.html` from the repo's `main` branch
  (OTA_URL in MainActivity.kt). If it changed, it's applied on the next launch.
  Edit index.html, commit, push - no new APK needed. Native changes still need a new APK.
- Keep the string `familytree.v1` in index.html (OTA sanity check). A bad OTA file falls back to the bundled one.
- A newly installed APK always replaces any older OTA copy.
- Export PDF / backup use the system "save file" picker; restore uses the file picker.

CI: push to main, then Actions > Build APK > download `family-tree-debug-apk`.
