# Family Tree (native Android, Kotlin)

- Add people (name, born, died, notes), link parents and partners; children/siblings are derived
- People list + Tree view, search, tap anyone to see relatives
- Export PDF (descendant tree + A-Z index, full Unicode), JSON backup/restore
- Handles 500+ people (menu > "Load 500 demo people" to test). Data stays on the device.

## Build the APK with CI
```
git init && git add . && git commit -m "Family tree app"
git branch -M main && git remote add origin <your-repo-url> && git push -u origin main
```
GitHub > Actions > "Build APK" > latest run > download `family-tree-debug-apk` > unzip > install `app-debug.apk`.

No Gradle wrapper is committed; CI installs Gradle 8.9. In Android Studio you can also just open this folder.
