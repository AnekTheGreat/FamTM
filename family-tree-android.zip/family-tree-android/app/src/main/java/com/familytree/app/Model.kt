package com.familytree.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.UUID

class Person(
    val id: String, var name: String, var birth: String, var death: String, var note: String,
    var parents: MutableList<String>, var partners: MutableList<String>
)

class Row(val p: Person, val depth: Int, val title: String, val sub: String)

fun life(p: Person) = if (p.birth.isEmpty() && p.death.isEmpty()) "" else p.birth.take(4) + "–" + p.death.take(4)
fun key(p: Person) = p.birth.ifEmpty { "9999" } + p.name

fun age(p: Person): String {
    val b = p.birth.take(4).toIntOrNull() ?: return ""
    val e = p.death.take(4).toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
    return if (e >= b) (if (p.death.isEmpty()) "Age " else "Lived ") + (e - b) else ""
}

object Store {
    val all = ArrayList<Person>()
    private lateinit var file: File
    private var index: Map<String, Person>? = null

    fun get(id: String): Person? {
        val m = index ?: all.associateBy { it.id }.also { index = it }
        return m[id]
    }

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "people.json")
        if (file.exists()) runCatching { replace(parse(file.readText()), false) }
    }

    fun replace(l: List<Person>, save: Boolean = true) {
        all.clear(); all.addAll(l); index = null
        if (save) save()
    }

    fun save() {
        index = null
        val t = File(file.path + ".tmp")
        t.writeText(json())
        t.renameTo(file)
    }

    fun remove(id: String) {
        all.removeAll { it.id == id }
        all.forEach { it.parents.remove(id); it.partners.remove(id) }
        save()
    }

    fun kids(id: String) = all.filter { id in it.parents }.sortedBy(::key)

    fun descendants(id: String): Set<String> {
        val s = HashSet<String>(); val st = mutableListOf(id)
        while (st.isNotEmpty()) {
            val x = st.removeAt(st.size - 1)
            all.forEach { c -> if (x in c.parents && s.add(c.id)) st.add(c.id) }
        }
        return s
    }

    fun json(): String = JSONArray(all.map {
        JSONObject().put("id", it.id).put("name", it.name).put("birth", it.birth).put("death", it.death)
            .put("note", it.note).put("parents", JSONArray(it.parents)).put("partners", JSONArray(it.partners))
    }).toString()

    private fun strs(a: JSONArray?): MutableList<String> =
        if (a == null) mutableListOf() else (0 until a.length()).map { a.getString(it) }.toMutableList()

    fun parse(s: String): List<Person> {
        val a = JSONArray(s)
        val l = (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Person(o.getString("id"), o.getString("name"), o.optString("birth"), o.optString("death"), o.optString("note"),
                strs(o.optJSONArray("parents")), strs(o.optJSONArray("partners")))
        }
        val ids = l.map { it.id }.toSet()
        l.forEach { x ->
            x.parents.retainAll(ids); while (x.parents.size > 2) x.parents.removeAt(2)
            x.partners.retainAll(ids)
        }
        return l
    }

    fun demo(n: Int = 520) {
        val f = listOf("Ava", "Noah", "Mia", "Liam", "Zoe", "Ethan", "Ivy", "Omar", "Lena", "Raj", "Maya", "Leo", "Nora", "Kai", "Sara", "Ben")
        val s = listOf("Smith", "Patel", "Garcia", "Kim", "Nguyen", "Brown", "Rossi", "Khan")
        val c0 = all.size
        fun cnt() = all.size - c0
        fun mk(b: Int, pa: List<String> = emptyList()): Person {
            val d = if (b < 1950 && Math.random() < .8) "${b + 60 + (Math.random() * 30).toInt()}" else ""
            val p = Person(UUID.randomUUID().toString(), "${f.random()} ${s.random()}", "$b", d, "", pa.toMutableList(), mutableListOf())
            all.add(p); return p
        }
        fun wed(a: Person, b: Person) { a.partners.add(b.id); b.partners.add(a.id) }
        var gen = ArrayList<Pair<Person, Person>>(); var y = 1880
        for (i in 0 until 5) { val a = mk(y); val b = mk(y + 2); wed(a, b); gen.add(a to b) }
        while (cnt() < n) {
            val nx = ArrayList<Pair<Person, Person>>(); y += 28
            for ((a, b) in gen) {
                val m = 2 + (Math.random() * 3).toInt(); var k = 0
                while (k < m && cnt() < n) {
                    val c = mk(y + k * 2, listOf(a.id, b.id))
                    if (cnt() < n) { val sp = mk(y + k * 2 + 1); wed(c, sp); nx.add(c to sp) }
                    k++
                }
            }
            gen = nx
        }
        save()
    }
}

fun treeRows(): List<Row> {
    val kids = HashMap<String, MutableList<Person>>()
    Store.all.forEach { c -> c.parents.forEach { kids.getOrPut(it) { mutableListOf() }.add(c) } }
    val seen = HashSet<String>(); val out = ArrayList<Row>()
    fun go(p: Person, d: Int) {
        seen.add(p.id)
        val ps = p.partners.mapNotNull { Store.get(it) }
        ps.forEach { if (it.parents.isEmpty()) seen.add(it.id) }
        out.add(Row(p, d, p.name + ps.joinToString("") { " & " + it.name }, life(p)))
        (listOf(p) + ps).flatMap { kids[it.id] ?: emptyList() }.distinct().sortedBy(::key).forEach { if (it.id !in seen) go(it, d + 1) }
    }
    Store.all.filter { it.parents.isEmpty() }.sortedBy(::key).forEach { if (it.id !in seen) go(it, 0) }
    Store.all.forEach { if (it.id !in seen) go(it, 0) }
    return out
}
