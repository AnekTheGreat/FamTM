package com.familytree.app

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.OutputStream
import java.text.DateFormat
import java.util.Date

fun writePdf(out: OutputStream) {
    val doc = PdfDocument(); val w = 595; val h = 842; val m = 44f
    val reg = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f }
    val bold = Paint(reg).apply { typeface = Typeface.DEFAULT_BOLD }
    val head = Paint(bold).apply { textSize = 14f }
    val title = Paint(bold).apply { textSize = 22f }
    val small = Paint(reg).apply { textSize = 9f; color = Color.DKGRAY }
    var n = 0; var pg: PdfDocument.Page? = null; var y = 0f
    fun finish() { pg?.let { it.canvas.drawText("Page $n", w / 2f - 18, h - 20f, small); doc.finishPage(it) } }
    fun line(name: String, sub: String, x: Float, p: Paint = bold, gap: Float = 15f) {
        if (pg == null || y > h - m) { finish(); n++; pg = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create()); y = m + 10 }
        val c = pg!!.canvas
        c.drawText(name, x, y, p)
        if (sub.isNotEmpty()) c.drawText(sub, x + p.measureText(name) + 8, y, small)
        y += gap
    }
    line("Family Tree", "", m, title, 24f)
    line("${Store.all.size} people · ${DateFormat.getDateInstance().format(Date())}", "", m, small, 28f)
    line("Descendant tree", "", m, head, 22f)
    treeRows().forEach { line(it.title, it.sub, m + minOf(it.depth, 24) * 14f) }
    y += 14f
    line("Everyone (A–Z)", "", m, head, 22f)
    Store.all.sortedBy { it.name.lowercase() }.forEach { line(it.name, life(it), m, reg, 13f) }
    finish(); doc.writeTo(out); doc.close()
}
