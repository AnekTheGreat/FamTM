package com.familytree.app

import android.content.DialogInterface
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.color.MaterialColors
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private val rows = ArrayList<Row>()
    private lateinit var rowAdapter: RowAdapter
    private lateinit var info: TextView
    private var tree = false
    private var query = ""
    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val wc = ViewGroup.LayoutParams.WRAP_CONTENT

    private val pdfL = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
        if (u != null) write(u) { writePdf(it) }
    }
    private val jsonL = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) write(u) { it.write(Store.json().toByteArray()) }
    }
    private val openL = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) restore(u)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Yes") { _, _ -> ok() }.setNegativeButton("Cancel", null).show()
    }

    private fun write(u: Uri, f: (OutputStream) -> Unit) {
        try { contentResolver.openOutputStream(u)?.use(f); toast("Saved") } catch (e: Exception) { toast("Save failed: ${e.message}") }
    }

    private fun restore(u: Uri) {
        try {
            val l = Store.parse(contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() })
            confirm("Replace current data with ${l.size} people from this backup?") { Store.replace(l); refresh() }
        } catch (e: Exception) { toast("Not a valid backup file") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        rowAdapter = RowAdapter()
        val tabs = TabLayout(this).apply {
            addTab(newTab().setText("People")); addTab(newTab().setText("Tree"))
            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(t: TabLayout.Tab) { tree = t.position == 1; refresh() }
                override fun onTabUnselected(t: TabLayout.Tab) {}
                override fun onTabReselected(t: TabLayout.Tab) {}
            })
        }
        val search = EditText(this).apply {
            hint = "Search people"; setSingleLine(); doAfterTextChanged { query = it.toString(); refresh() }
        }
        info = TextView(this).apply { setPadding(dp(16), dp(6), dp(16), dp(2)); alpha = .7f }
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(context); adapter = rowAdapter
            setPadding(0, 0, 0, dp(88)); clipToPadding = false
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tabs)
            addView(search, LinearLayout.LayoutParams(mp, wc).apply { setMargins(dp(12), dp(4), dp(12), 0) })
            addView(info)
            addView(rv, LinearLayout.LayoutParams(mp, 0, 1f))
        }
        val fab = FloatingActionButton(this).apply {
            setImageResource(android.R.drawable.ic_input_add); setOnClickListener { form(null) }
        }
        val root = FrameLayout(this).apply {
            addView(col, FrameLayout.LayoutParams(mp, mp))
            addView(fab, FrameLayout.LayoutParams(wc, wc, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(20)) })
        }
        setContentView(root)
        refresh()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        listOf("Export PDF", "Backup (JSON)", "Restore backup", "Load 500 demo people", "Delete everyone")
            .forEachIndexed { i, t -> menu.add(0, i, i, t) }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            0 -> if (Store.all.isEmpty()) toast("Nothing to export") else pdfL.launch("family-tree.pdf")
            1 -> jsonL.launch("family-tree-backup.json")
            2 -> openL.launch(arrayOf("*/*"))
            3 -> { Store.demo(); refresh(); toast("Added demo people") }
            4 -> confirm("Delete ALL people? Back up first.") { Store.replace(emptyList()); refresh() }
        }
        return true
    }

    private fun refresh() {
        rows.clear()
        val q = query.trim()
        if (tree) rows.addAll(treeRows().filter { q.isEmpty() || it.p.name.contains(q, true) })
        else Store.all.filter { it.name.contains(q, true) }.sortedBy { it.name.lowercase() }.forEach { p ->
            val par = p.parents.mapNotNull { Store.get(it)?.name }
            val sub = listOf(life(p), if (par.isEmpty()) "" else "Child of " + par.joinToString(" & ")).filter { it.isNotEmpty() }
            rows.add(Row(p, 0, p.name, sub.joinToString(" · ")))
        }
        info.text = if (Store.all.isEmpty()) "No one yet – tap + to add, or use the menu to load demo data" else "${Store.all.size} people"
        rowAdapter.notifyDataSetChanged()
    }

    inner class RowAdapter : RecyclerView.Adapter<RowAdapter.VH>() {
        inner class VH(val v: LinearLayout) : RecyclerView.ViewHolder(v)

        override fun onCreateViewHolder(parent: ViewGroup, type: Int): VH {
            val tv = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            val v = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; layoutParams = RecyclerView.LayoutParams(mp, wc); setBackgroundResource(tv.resourceId)
                addView(TextView(context).apply { textSize = 16f; setTypeface(null, Typeface.BOLD) })
                addView(TextView(context).apply { textSize = 13f; alpha = .7f })
            }
            return VH(v)
        }

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val r = rows[i]
            h.v.setPadding(dp(16 + minOf(r.depth, 20) * 14), dp(10), dp(16), dp(10))
            (h.v.getChildAt(0) as TextView).text = r.title
            (h.v.getChildAt(1) as TextView).text = r.sub
            h.v.setOnClickListener { detail(r.p) }
        }
    }

    private fun detail(p: Person) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val accent = MaterialColors.getColor(this, androidx.appcompat.R.attr.colorPrimary, Color.GRAY)
        lateinit var d: AlertDialog
        fun add(t: String, bold: Boolean = false, go: Person? = null) {
            box.addView(TextView(this).apply {
                text = t; textSize = if (bold) 13f else 16f; setPadding(0, dp(if (bold) 14 else 6), 0, dp(4))
                if (bold) setTypeface(null, Typeface.BOLD)
                if (go != null) { setTextColor(accent); setOnClickListener { d.dismiss(); detail(go) } }
            })
        }
        fun group(t: String, l: List<Person>) { if (l.isNotEmpty()) { add(t, true); l.forEach { add(it.name + "  " + life(it), go = it) } } }
        val dates = listOf(
            if (p.birth.isNotEmpty()) "Born ${p.birth}" else "", if (p.death.isNotEmpty()) "Died ${p.death}" else "", age(p)
        ).filter { it.isNotEmpty() }.joinToString(" · ").ifEmpty { "No dates" }
        add(dates)
        if (p.note.isNotEmpty()) add(p.note)
        group("PARENTS", p.parents.mapNotNull { Store.get(it) })
        group("PARTNERS", p.partners.mapNotNull { Store.get(it) })
        group("CHILDREN", Store.kids(p.id))
        group("SIBLINGS", p.parents.flatMap { Store.kids(it) }.distinct().filter { it.id != p.id })
        d = AlertDialog.Builder(this).setTitle(p.name).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Done", null)
            .setNeutralButton("Edit") { _, _ -> form(p) }
            .setNegativeButton("Add relative") { _, _ -> addRelative(p) }
            .create()
        d.show()
    }

    private fun addRelative(p: Person) {
        val opts = listOfNotNull(if (p.parents.size < 2) "Parent" else null, "Partner", "Child")
        AlertDialog.Builder(this).setTitle("Add for ${p.name}").setItems(opts.toTypedArray()) { _, i ->
            when (opts[i]) {
                "Parent" -> form(null, child = p)
                "Partner" -> form(null, partner = p)
                else -> form(null, parent = p)
            }
        }.show()
    }

    private fun pick(exclude: Set<String>, cb: (Person) -> Unit) {
        val et = EditText(this).apply { hint = "Search by name"; setSingleLine() }
        val lv = ListView(this)
        val ad = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ArrayList())
        lv.adapter = ad
        var shown = listOf<Person>()
        fun filter() {
            val s = et.text.toString()
            shown = Store.all.filter { it.id !in exclude && it.name.contains(s, true) }.sortedBy { it.name.lowercase() }.take(100)
            ad.clear(); ad.addAll(shown.map { it.name + "  " + life(it) }); ad.notifyDataSetChanged()
        }
        et.doAfterTextChanged { filter() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            addView(et); addView(lv, LinearLayout.LayoutParams(mp, dp(320)))
        }
        val d = AlertDialog.Builder(this).setTitle("Choose person").setView(box).setNegativeButton("Cancel", null).create()
        lv.setOnItemClickListener { _, _, i, _ -> d.dismiss(); cb(shown[i]) }
        filter(); d.show()
    }

    private fun form(e: Person?, child: Person? = null, partner: Person? = null, parent: Person? = null) {
        val par = (e?.parents ?: emptyList<String>()).toMutableList()
        val prt = (e?.partners ?: emptyList<String>()).toMutableList()
        if (parent != null) { par.add(parent.id); if (parent.partners.size == 1) par.add(parent.partners[0]) }
        if (partner != null) prt.add(partner.id)
        fun field(h: String, v: String) = EditText(this).apply { hint = h; setText(v) }
        val nm = field("Name", e?.name ?: "").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS }
        val bi = field("Born (YYYY or YYYY-MM-DD)", e?.birth ?: "")
        val de = field("Died (leave blank if living)", e?.death ?: "")
        val no = field("Notes", e?.note ?: "")
        val rel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val err = TextView(this).apply { setTextColor(Color.RED) }
        fun redraw() {
            rel.removeAllViews()
            fun row(label: String, id: String, list: MutableList<String>) {
                rel.addView(LinearLayout(this).apply {
                    addView(TextView(context).apply { text = "$label: ${Store.get(id)?.name}"; textSize = 16f }, LinearLayout.LayoutParams(0, wc, 1f))
                    addView(TextView(context).apply { text = "  ✕  "; textSize = 18f; setOnClickListener { list.remove(id); redraw() } })
                })
            }
            par.toList().forEach { row("Parent", it, par) }
            prt.toList().forEach { row("Partner", it, prt) }
            rel.addView(LinearLayout(this).apply {
                if (par.size < 2) addView(Button(context).apply {
                    text = "+ Parent"
                    setOnClickListener {
                        val ex = setOf(e?.id ?: "") + par + (e?.let { Store.descendants(it.id) } ?: emptySet())
                        pick(ex) { x -> par.add(x.id); redraw() }
                    }
                })
                addView(Button(context).apply {
                    text = "+ Partner"
                    setOnClickListener { pick(setOf(e?.id ?: "") + prt) { x -> prt.add(x.id); redraw() } }
                })
            })
        }
        redraw()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            listOf(nm, bi, de, no).forEach { addView(it) }; addView(rel); addView(err)
        }
        val b = AlertDialog.Builder(this).setTitle(if (e == null) "Add person" else "Edit person")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save", null).setNegativeButton("Cancel", null)
        if (e != null) b.setNeutralButton("Delete", null)
        val d = b.create()
        d.setOnShowListener {
            d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val name = nm.text.toString().trim(); val bs = bi.text.toString().trim(); val ds = de.text.toString().trim()
                val re = Regex("""\d{4}(-\d\d(-\d\d)?)?""")
                val bad = when {
                    name.isEmpty() -> "Name is required"
                    (bs.isNotEmpty() && !re.matches(bs)) || (ds.isNotEmpty() && !re.matches(ds)) -> "Dates: YYYY, YYYY-MM or YYYY-MM-DD"
                    bs.isNotEmpty() && ds.isNotEmpty() && ds.take(4) < bs.take(4) -> "Death can't be before birth"
                    else -> null
                }
                if (bad != null) { err.text = bad; return@setOnClickListener }
                val o = e ?: Person(UUID.randomUUID().toString(), "", "", "", "", mutableListOf(), mutableListOf()).also { Store.all.add(it) }
                o.name = name; o.birth = bs; o.death = ds; o.note = no.text.toString().trim(); o.parents = par; o.partners = prt
                Store.all.forEach { x ->
                    if (x !== o) {
                        val has = o.id in x.partners; val want = x.id in prt
                        if (want && !has) x.partners.add(o.id)
                        if (!want && has) x.partners.remove(o.id)
                    }
                }
                if (child != null && child.parents.size < 2 && o.id !in child.parents) child.parents.add(o.id)
                Store.save(); refresh(); d.dismiss(); detail(o)
            }
            if (e != null) d.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                confirm("Delete ${e.name}? Links to them are removed.") { Store.remove(e.id); d.dismiss(); refresh() }
            }
        }
        d.show()
    }
}
